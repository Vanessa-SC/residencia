{
	"constancias": [

		{
			"folio": "AB3214",
			"curso": "Diplomado para la Formación y Desarrollo de Competencias Docentes - Módulo II: Planeación del proceso de Aprendizaje",
			"fecha": "18 al 22 de Junio 2019, 9:00 - 15:00 Hrs."
		}, {
			"folio": "AB3220",
			"curso": "Diplomado para la Formación de Tutores - Módulo II: Programa de Tutorías Semipresencial",
			"fecha": "8 al 22 de Junio 2019, 9:00 - 15:00 Hrs."
		}, {
			"folio": "AC1240",
			"curso": "Diplomado para la Formación de Tutores — Módulo II: Programa de Tutorías en línea",
			"fecha": "18 al 22 de Junio 2019, Horario abierto"
		}
	]
}