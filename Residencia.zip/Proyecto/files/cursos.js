{
  "cursos": [{
      "id": 1,
      "validado": "cancel",
      "maestro": "I.S.C. Cristabel Armstrong Aramburo",
      "curso": "Diplomado para la Formación y Desarrollo de Competencias Docentes - Módulo II: Planeación del proceso de Aprendizaje",
      "fecha": "18 al 22 de Junio 2019, 9:00 - 15:00 Hrs."
    },
    {
      "id": 2,
      "validado": "ok",
      "maestro": "Dra. Dora Luz González Báñales",
      "curso": "Diplomado para la Formación de Tutores - Módulo II: Programa de Tutorías Semipresencial",
      "fecha": "8 al 22 de Junio 2019, 9:00 - 15:00 Hrs."
    },
    {
      "id": 3,
      "validado": "ok",
      "maestro": "Ing. Carlos Valenzuela Martinez",
      "curso": "Diplomado para la Formación de Tutores — Módulo II: Programa de Tutorías en línea",
      "fecha": "18 al 22 de Junio 2019, Horario abierto"
    }
  ],
  "documentos": [{
      "numero": "1",
      "documento": "Diseño del curso (Ficha Tecnica)",
      "validado": "ok"
    },
    {
      "numero": "2",
      "documento": "Currículum",
      "validado": "cancel"
    },
    {
      "numero": "3",
      "documento": "Programa",
      "validado": "ok"
    }
  ],
  "periodo" : "Agosto/Diciembre 2020"
}