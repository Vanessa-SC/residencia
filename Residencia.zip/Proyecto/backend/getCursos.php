<?php

$jsonfile = file_get_contents("../js/AngularJS/cursos.js");
print($jsonfile);

?>